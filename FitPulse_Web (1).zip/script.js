const activities = [
  {id:"walking", name:"เดิน", en:"Walking", icon:"🚶", met:3.5, desc:"เดินสบาย ๆ / เดินเร็ว"},
  {id:"running", name:"วิ่ง", en:"Running", icon:"🏃", met:8.3, desc:"วิ่งระดับปานกลาง"},
  {id:"cycling", name:"ปั่นจักรยาน", en:"Cycling", icon:"🚴", met:7.5, desc:"ปั่นจักรยานระดับปานกลาง"},
  {id:"swimming", name:"ว่ายน้ำ", en:"Swimming", icon:"🏊", met:6.0, desc:"ว่ายน้ำทั่วไป"},
  {id:"football", name:"ฟุตบอล", en:"Football", icon:"⚽", met:7.0, desc:"เล่นฟุตบอลทั่วไป"},
  {id:"badminton", name:"แบดมินตัน", en:"Badminton", icon:"🏸", met:5.5, desc:"เล่นเพื่อออกกำลัง"},
  {id:"basketball", name:"บาสเกตบอล", en:"Basketball", icon:"🏀", met:6.5, desc:"เล่นระดับทั่วไป"},
  {id:"dance", name:"เต้น", en:"Dance", icon:"💃", met:5.5, desc:"เต้นต่อเนื่องระดับปานกลาง"}
];

const $ = id => document.getElementById(id);
const activityGrid = $("activityGrid");
const select = $("activity");
const form = $("calcForm");
const historyKey = "fitpulse_history";
let lastResult = null;

activities.forEach(a => {
  activityGrid.insertAdjacentHTML("beforeend", `
    <article class="activity" data-id="${a.id}">
      <div class="icon">${a.icon}</div>
      <h3>${a.name}</h3>
      <p>${a.en} • ${a.desc}</p>
    </article>`);
  select.insertAdjacentHTML("beforeend", `<option value="${a.id}">${a.icon} ${a.name} — ${a.en}</option>`);
});

document.querySelectorAll(".activity").forEach(card => {
  card.addEventListener("click", () => {
    select.value = card.dataset.id;
    document.querySelector("#calculator").scrollIntoView({behavior:"smooth"});
  });
});

function calculate() {
  const a = activities.find(x => x.id === select.value);
  const minutes = Number($("duration").value);
  const weight = Number($("weight").value);
  if (!a || !minutes || !weight) return;
  // Approximation: kcal ≈ MET × 3.5 × kg / 200 × minutes
  const kcal = Math.round(a.met * 3.5 * weight / 200 * minutes);
  lastResult = {activity:a, minutes, weight, kcal, time:new Date().toLocaleString("th-TH")};
  $("resultKcal").textContent = kcal.toLocaleString();
  $("resultText").textContent = `${a.name} ${minutes} นาที • ผลลัพธ์นี้เป็นค่าพลังงานโดยประมาณ`;
  $("resultBar").style.width = Math.min(100, Math.max(8, kcal / 5)) + "%";
  $("saveBtn").disabled = false;
  $("heroKcal").textContent = kcal.toLocaleString();
  $("heroMinutes").textContent = minutes;
}

form.addEventListener("submit", e => { e.preventDefault(); calculate(); });

$("saveBtn").addEventListener("click", () => {
  if (!lastResult) return;
  const data = JSON.parse(localStorage.getItem(historyKey) || "[]");
  data.unshift({
    activity:lastResult.activity.name,
    icon:lastResult.activity.icon,
    minutes:lastResult.minutes,
    kcal:lastResult.kcal,
    time:lastResult.time
  });
  localStorage.setItem(historyKey, JSON.stringify(data.slice(0,30)));
  renderHistory();
  $("saveBtn").textContent = "✓ บันทึกแล้ว";
  setTimeout(() => $("saveBtn").textContent = "＋ บันทึกกิจกรรมนี้", 1200);
});

function renderHistory() {
  const data = JSON.parse(localStorage.getItem(historyKey) || "[]");
  $("totalSessions").textContent = data.length;
  $("totalMinutes").textContent = data.reduce((s,x)=>s+x.minutes,0).toLocaleString();
  $("totalKcal").textContent = data.reduce((s,x)=>s+x.kcal,0).toLocaleString();

  if (!data.length) {
    $("historyList").innerHTML = `<div class="empty">ยังไม่มีประวัติ — ลองคำนวณกิจกรรมแรกของคุณดู</div>`;
    return;
  }
  $("historyList").innerHTML = data.map((x,i)=>`
    <div class="history-item">
      <div><b>${x.icon} ${x.activity}</b><small>${x.time}</small></div>
      <div class="time">${x.minutes} นาที</div>
      <div class="kcal">${x.kcal} kcal</div>
      <button class="delete" onclick="deleteHistory(${i})">×</button>
    </div>`).join("");
}
window.deleteHistory = i => {
  const data = JSON.parse(localStorage.getItem(historyKey) || "[]");
  data.splice(i,1); localStorage.setItem(historyKey, JSON.stringify(data)); renderHistory();
};
$("clearHistory").addEventListener("click", () => {
  if(confirm("ต้องการล้างประวัติทั้งหมดหรือไม่?")) {
    localStorage.removeItem(historyKey); renderHistory();
  }
});

$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("bright");
});

renderHistory();
calculate();
